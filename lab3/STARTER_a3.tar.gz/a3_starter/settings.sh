ZKSTRING=snorkel.uwaterloo.ca:2181
